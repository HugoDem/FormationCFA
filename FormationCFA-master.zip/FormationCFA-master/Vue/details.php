<div>
	<h1><?php echo $school ?></h1>
</div>