<!DOCTYPE html>
<html>
<head>
	<title>User existing</title>
</head>
<body>
<p>Désolé, l'utilisateur existe déjà !</p>
</body>
</html>