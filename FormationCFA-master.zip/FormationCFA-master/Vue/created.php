<!DOCTYPE html>
<html>
<head>
	<title>User created</title>
</head>
<body>
<p>Name: <?php echo $createdUser->getName() ?></p>
<p>Mail: <?php echo $createdUser->getMail() ?></p>
</body>
</html>