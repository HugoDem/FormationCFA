<!DOCTYPE html>
<html>
<head>
	<title>Success</title>
</head>
<body>
<h1>You logged in ! </h1>


<p><?php echo $connectedUser->getName(); ?></p>
</body>
</html>