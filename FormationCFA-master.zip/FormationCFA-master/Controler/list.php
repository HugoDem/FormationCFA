<?php

$list=["ISEP", "centrale","ECE", "EFREI","ESTP"];
include_once("Vue/list.php");

?>